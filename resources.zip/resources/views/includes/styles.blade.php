<link rel="stylesheet" href=" {{url('user/style/css/style.css')}} ">
<link rel="stylesheet" href=" {{url('user/style/bootstrap/bootstrap.css')}} ">